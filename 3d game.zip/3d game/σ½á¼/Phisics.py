class Phisics:
    def __init__(self):
        self.area = [([], [])]

    def set_map(self, map_):
        self.area = map_

    def add_object(self, obj):
        self.area.append(obj)

    def get_map(self):
        return self.area