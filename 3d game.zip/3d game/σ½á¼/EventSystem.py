import pygame

class EventSystem:
    def __init__(self):
        self.pygame = pygame
        self.events = {}

    def connect(self, event, function):
        if eval(f'pygame.{event}') in self.events.keys():
            self.events[eval(f'pygame.{event}')].append(function)
        else:
            self.events[eval(f'pygame.{event}')] = [function]

    def Update(self):
        events = self.pygame.event.get()
        for event in events:
            pass