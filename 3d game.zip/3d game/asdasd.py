for i in range(100):
    print(i % 30)