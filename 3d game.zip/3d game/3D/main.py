from Game import Game


grid_plots = []
n = 20
[[grid_plots.append([x*2, y*2, 0]) for y in range(-n, n)] for x in range(-n, n)]
grid_polygons = []
[[grid_polygons.extend([[x+2*n*y, x+2*n*y+1, x+2*n*(y+1)], [x+2*n*y, x+2*n*y+1, x+2*n*(y+1)+1]]) for x in range(n*2-1)] for y in range(n*2-1)]
grid = (grid_plots, grid_polygons)

game = Game()

game.init()
game.init_phisics()
game.init_screen((800, 600), 'main.py')

game.Phisics.set_map([grid])

cam1 = game.Object.Camera(game, game.screen_size, 600)
game.add_camera(cam1)


def rotate_time():
    pass


delay_flag = game.Object.Delay()
def sqr2_script():
    sqr2.tick()  # Обновлсяем объект
    delay_flag.tick()  # Обновляем таймер
    if delay_flag.get_flag():  # Если в таймере 0 - вернйт True
        sqr2.rotate_on(45, 1, 'x')  # Устанавливаем поворот НА(поворот К - rotate_to)
        delay_flag.set(60)  # Устанавливаем таймер на 60 кадров(тиков), если поставить -1, считать не будет

delay_flag5 = game.Object.Delay()
def sqr5_script():
    sqr5.tick()
    delay_flag5.tick()
    if delay_flag5.get_flag():
        sqr5.rotate_on(45, 2, 'x')
        print('hello')
        delay_flag5.set(180)



game.EventSystem1 = game.EventSystem(game)

sqr1 = game.Object.DynamicObject(game, 'sqr1', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)],
                                                [(0, 1, 2), (0, 3, 2)]])
game.add_object(sqr1)

sqr1.move((5, 0, 0))
sqr1.rotate((0, 45, 0))

sqr2 = game.Object.DynamicObject(game, 'sqr2', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)],
                                                [(0, 1, 2), (0, 3, 2)]])
sqr1.add_child(sqr2)
sqr2.move((1, 0, 0))
sqr2.connect(game.EventSystem1, sqr2_script)

sqr5 = game.Object.DynamicObject(game, 'sqr5', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)],
                                                [(0, 1, 2), (0, 3, 2)]])
sqr1.add_child(sqr5)
sqr5.move((1, 1, 0))
sqr5.connect(game.EventSystem1, sqr5_script)


cam1.cam1_v = (0, 0, 0)
cam1.delta_v = 0.2


def move_cam_up(event):
    cam1.cam1_v = game.Math.m_sum(cam1.cam1_v, (0, 0, cam1.delta_v))
def move_cam_down(event):
    cam1.cam1_v = game.Math.m_sum(cam1.cam1_v, (0, 0, -cam1.delta_v))
def move_cam_left(event):
    cam1.cam1_v = game.Math.m_sum(cam1.cam1_v, (0, -cam1.delta_v, 0))
def move_cam_right(event):
    cam1.cam1_v = game.Math.m_sum(cam1.cam1_v, (0, cam1.delta_v, 0))
def move_cam_forward(event):
    cam1.cam1_v = game.Math.m_sum(cam1.cam1_v, (cam1.delta_v, 0, 0))
def move_cam_backward(event):
    cam1.cam1_v = game.Math.m_sum(cam1.cam1_v, (-cam1.delta_v, 0, 0))

def move_up(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, 0, -SPEED_SHIP))
def move_down(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, 0, SPEED_SHIP))
def move_left(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (-SPEED_SHIP, 0, 0))
def move_right(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (SPEED_SHIP, 0, 0))
def move_forward(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, SPEED_SHIP, 0))
def move_backward(event):

    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, -SPEED_SHIP, 0))


def move_up_stop(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, 0, SPEED_SHIP))
def move_down_stop(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, 0, -SPEED_SHIP))
def move_left_stop(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (SPEED_SHIP, 0, 0))
def move_right_stop(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (-SPEED_SHIP, 0, 0))
def move_forward_stop(event):
    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, -SPEED_SHIP, 0))
def move_backward_stop(event):

    global speed_ship
    speed_ship = game.Math.m_sum(speed_ship, (0, SPEED_SHIP, 0))


game.EventSystem1.add_key_down_func(game.pygame.K_s, move_backward)
game.EventSystem1.add_key_down_func(game.pygame.K_w, move_forward)
game.EventSystem1.add_key_down_func(game.pygame.K_d, move_right)
game.EventSystem1.add_key_down_func(game.pygame.K_a, move_left)

game.EventSystem1.add_key_up_func(game.pygame.K_s, move_backward_stop)
game.EventSystem1.add_key_up_func(game.pygame.K_w, move_forward_stop)
game.EventSystem1.add_key_up_func(game.pygame.K_d, move_right_stop)
game.EventSystem1.add_key_up_func(game.pygame.K_a, move_left_stop)

game.EventSystem1.add_key_down_func(game.pygame.K_LSHIFT, move_down)
game.EventSystem1.add_key_down_func(game.pygame.K_RSHIFT, move_down)
game.EventSystem1.add_key_down_func(game.pygame.K_SPACE, move_up)

game.EventSystem1.add_key_up_func(game.pygame.K_LSHIFT, move_down_stop)
game.EventSystem1.add_key_up_func(game.pygame.K_RSHIFT, move_down_stop)
game.EventSystem1.add_key_up_func(game.pygame.K_SPACE, move_up_stop)


game.EventSystem1.add_key_down_func(game.pygame.K_UP, move_cam_forward)
game.EventSystem1.add_key_down_func(game.pygame.K_DOWN, move_cam_backward)
game.EventSystem1.add_key_down_func(game.pygame.K_RIGHT, move_cam_right)
game.EventSystem1.add_key_down_func(game.pygame.K_LEFT, move_cam_left)

def key_up(event):
    if event.key in [game.pygame.K_SPACE, game.pygame.K_LSHIFT, game.pygame.K_RSHIFT]:
        cam1.cam1_v = (cam1.cam1_v[0], cam1.cam1_v[1], 0)
    elif event.key in [game.pygame.K_w, game.pygame.K_s, game.pygame.K_UP, game.pygame.K_DOWN]:
        cam1.cam1_v = (0, cam1.cam1_v[1], cam1.cam1_v[2])
    elif event.key in [game.pygame.K_a, game.pygame.K_s, game.pygame.K_LEFT, game.pygame.K_RIGHT]:
        cam1.cam1_v = (cam1.cam1_v[0], 0, cam1.cam1_v[2])


game.EventSystem1.connect(game.pygame.KEYUP, key_up)


def move_cam1():
    cam1.move(cam1.cam1_v)

game.EventSystem1.add_object_func(move_cam1)

cam1.dpi = 100

def rotate_cam1(event):
    if event.buttons == (1, 0, 0):
        pass
        # print(event.dict)
        # cam1.rotate((0, event.rel[1] / cam1.scale * cam1.dpi, -event.rel[0] / cam1.scale * cam1.dpi))
        fregat.rotate((0, 0, event.rel[0]))
        cam1.rotate((0, 0, -event.rel[0] * 2))  # Костыль!!!!!
    elif event.buttons == (0, 0, 1):
        plain_axis.rotate((0, 0, event.rel[0]))
        cam1.rotate((0, 0, -event.rel[0] * 2))  # Костыль!!!!!
        # cam1.rotate((0, event.rel[1] / cam1.scale * cam1.dpi, -event.rel[0] / cam1.scale * cam1.dpi))

game.EventSystem1.connect(game.pygame.MOUSEMOTION, rotate_cam1)

fregat = game.Object.DynamicObject(game, 'cactus1', game.Loader.ObjectLoader.load('Objects/spase_ship.obj'))
game.add_object(fregat)
# fregat.move((0, 0, 0))
# fregat.rotate((0, 0, 0))

cam1.rotate((0, 0, -90))
cam1.set_pos((0, -7, 1))

plain_axis = game.Object.DynamicObject(game, 'sqr5', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)],
                                                [(0, 1, 2), (0, 3, 2)]])

fregat.add_child(plain_axis)
plain_axis.set_pos((0,3,0))
plain_axis.add_child(cam1)


def fregat_skript():
    fregat.rotate((0, 0, 0))
    fregat.move(speed_ship)


fregat.connect(game.EventSystem1, fregat_skript)

# game.EventSystem1.add_object_func(sqr1_script)

clock = game.pygame.time.Clock()
clockfps = game.pygame.time.Clock()
time_counter = game.pygame.time.Clock()

SPEED_SHIP = 0.1
speed_ship = (0, 0, 0)

while True:
    time_counter.tick()

    game.EventSystem1.refresh()

    prerender = cam1.calc_pre_render()
    cam1.render(prerender)
    clock.tick(60)
    game.pygame.display.flip()
