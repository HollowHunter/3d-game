int get_int_size();
int get_float_size();
char* float_to_bytes(float num);
char* int_to_bytes(int num);
void free_mem(void* pointer);

void* get_map_pointer();

int get_obj_id(void *obj);

void* create_object(int plots_len, char* plots_in, int poly_len, char* polygons_in, int istextured, int tex_id, int tex_plots_len, char* tex_plots_in, char* surf_in, int iscamera);
void delete_object(void* object);

void add_obj_to_map(void* map_in, void* object);

void print_obj(void* object);

void print_map(void* map_in);

void move_object(void* object, float dx, float dy, float dz);
void place_object(void* object, float dx, float dy, float dz);
void rotate_object(void* object, float ax, float ay, float az);
void set_rot_object(void* object, float ax, float ay, float az);
void redact_plot(void* object, int plot, int new_x, int new_y, int new_z);

char* render_plots(void* map_in, void* cam_in, int size_x, int size_y, int scale);

void add_texture_to_map(void* map_in, int size_x, int size_y, unsigned char* texture);
