#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "map.h"
#include "main.h"

#include "my_math.c"
#include "render.c"
#include "physics.c"

int objects_total=0;

int get_int_size(){return sizeof(int);}
int get_float_size(){return sizeof(float);}
char* float_to_bytes(float num){float *res=(float*)malloc(sizeof(float));*res=num;return (char*) res;}
char* int_to_bytes(int num){int *res=(int*) malloc(sizeof(int));*res=num;return (char*) res;}


void free_mem(void* pointer)
{
//    printf("free(pointer:%p)\n", pointer);
//    printf("try to free: \n");
    free(pointer);
//    printf("|----success\n");
}


void* get_map_pointer()
{
    Map *map = (Map*) malloc(sizeof(Map));
    map -> objects_cont = 0;
    map -> tex_cont = 0;
    return map;
}


float** dim2d_float(int m, int n)
{
    float** a = (float**)malloc(m*sizeof(float*));

    for (int c = 0; c < m; c++) {
        a[c] = (float*)malloc(n*sizeof(float));
    }
    return a;
}


int** dim2d_int(int m, int n)
{
    int** a = (int**)malloc(m*sizeof(int*));

    for (int c = 0; c < m; c++) {
        a[c] = (int*)malloc(n*sizeof(int));
    }
    return a;
}


void* create_object(int plots_len, char* plots_in, int poly_len, char* polygons_in, int istextured, int tex_id, int tex_plots_len, char* tex_plots_in, char* surf_in, int iscamera)
{
    float *plots = (float*) plots_in;
    int* polygons = (int*) polygons_in;
    int* surfaces = (int*) surf_in;
    float* tex_plots = (float*) tex_plots_in;
    
    Object *object = (Object*) malloc(sizeof(Object));
    if (object==NULL) printf("6!\n");
    object -> id = objects_total;
    objects_total++;
    object -> children = 0;
    object -> iscamera = iscamera;
    
    object -> pos[0]=0;
    object -> pos[1]=0;
    object -> pos[2]=0;
    
    object -> rot[0]=0;
    object -> rot[1]=0;
    object -> rot[2]=0;
    
    object -> local_rot[0]=0;
    object -> local_rot[1]=0;
    object -> local_rot[2]=0;
    
    object -> v[0]=0;
    object -> v[1]=0;
    object -> v[2]=0;
    
    object -> plots_len = plots_len;
    object -> plots = dim2d_float(plots_len, 3);
    
    object -> poly_len = poly_len;
    object -> polygons = dim2d_int(poly_len, 3);
    object -> surfaces = dim2d_int(poly_len, 3);
    
    object -> tex_id = tex_id;
    object -> tex_plots_len = tex_plots_len;
    object -> istextured = istextured;
    object -> tex_plots = dim2d_float(tex_plots_len, 2);
    
    for(int i=0; i<tex_plots_len; i++)
    {
        object -> tex_plots[i][0] = tex_plots[i*2];
        object -> tex_plots[i][1] = tex_plots[i*2+1];
    }
    
    
    for(int i=0; i<plots_len; i++)
    {
        object -> plots[i][0] = plots[i*3];
        object -> plots[i][1] = plots[i*3+1];
        object -> plots[i][2] = plots[i*3+2];
    }
    
    for(int i=0; i<poly_len; i++)
    {
        object -> polygons[i][0] = polygons[i*3];
        object -> polygons[i][1] = polygons[i*3+1];
        object -> polygons[i][2] = polygons[i*3+2];
        
        object -> surfaces[i][0] = surfaces[i*3];
        object -> surfaces[i][1] = surfaces[i*3+1];
        object -> surfaces[i][2] = surfaces[i*3+2];
    }
    
    return object;
}


void delete_object(void* object)
{
    Object *obj = (Object*) object;
    
    for(int i=0; i<obj -> plots_len; i++)
    {
        free(obj -> plots[i]);
    }free(obj -> plots);
    
    for(int i=0; i<obj -> poly_len; i++)
    {
        free(obj -> polygons[i]);
    }free(obj -> polygons);
    
    for(int i=0; i<obj -> tex_plots_len; i++)
    {
        free(obj -> tex_plots[i]);
    }free(obj -> tex_plots);
    
    for(int i=0; i<obj -> children; i++)
    {
        free(obj -> child[i]);
    }free(obj -> child);
    free(object);
}


int get_obj_id(void* object)
{
    Object *obj = (Object*) object;
    return obj -> id;
}


void add_obj_to_map(void* map_in, void* object)
{
    Map *map = (Map*) map_in;
    Object *obj = (Object*) object;
    map -> objects_cont++;                                                             // Set new value of objects in map
    Object* *objects_last = map -> objects;                                            // Save old objects
    map -> objects = (Object**) malloc(sizeof(Object*) * map -> objects_cont);         // Get more memory
    for(int i=0; i < map -> objects_cont-1; i++){map -> objects[i] = objects_last[i];} // Set objects
    if(map->objects_cont>1)free(objects_last);                                         // Free memory if need
    map -> objects[map -> objects_cont - 1] = obj;                                     // Add new object
}

Texture create_tex(int size_x, int size_y, unsigned char *data)
{
    Texture new_tex;
    new_tex.size_x = size_x;
    new_tex.size_y = size_y;
    new_tex.pixels = malloc(size_x*size_y*4);
    for(int i=0; i<size_x*size_y*4; i++){new_tex.pixels[i] = data[i];}
    return new_tex;
}

void add_texture_to_map(void* map_in, int size_x, int size_y, unsigned char* texture)
{
    Map* map = (Map*) map_in;
    map -> tex_cont++;
    Texture* tex_last = map->textures;
    map -> textures = (Texture*) malloc(sizeof(Texture) * map -> tex_cont);
    for(int i=0; i < map -> tex_cont-1; i++){map -> textures[i] = tex_last[i];}
    if(map->tex_cont>1) free(tex_last);
    map -> textures[map->tex_cont-1] = create_tex(size_x, size_y, texture);
//    free(texture);
//    for(int i=0; i<size_x*size_y*4; i++)printf("%02x ", (unsigned char) map -> textures[map->tex_cont-1].pixels[i]);
//    printf("\n");
}


void print_obj(void* object)
{
    Object *obj = (Object*) object;
    printf("Object:\n|--id: %d\n", obj -> id);

    printf("|--plots: \n|--|--[(%.1f, %.1f, %.1f)", obj -> plots[0][0], obj -> plots[0][1], obj -> plots[0][2]);
    for(int i=1; i<obj -> plots_len; i++){printf(", \n|--|-- (%.1f, %.1f, %.1f)", obj -> plots[i][0], obj -> plots[i][1], obj -> plots[i][2]);}
    printf("]\n");
    printf("|--polygons:\n|--|--[(%d, %d, %d)", obj -> polygons[0][0], obj -> polygons[0][1], obj -> polygons[0][2]);
    for(int i=1; i<obj -> poly_len; i++){printf(", \n|--|-- (%d, %d, %d)", obj -> polygons[i][0], obj -> polygons[i][1], obj -> polygons[i][2]);}
    printf("]\n");
    if(obj->istextured)
    {
        printf("|--tex_id = %d\n", obj->tex_id);
        printf("|--tex_plots: \n|--|--[(%.1f, %.1f)", obj -> tex_plots[0][0], obj -> tex_plots[0][1]);
        for(int i=1; i<obj -> tex_plots_len; i++){printf(", \n|--|-- (%.1f, %.1f)", obj -> tex_plots[i][0], obj -> tex_plots[i][1]);}
        printf("]\n");
    }
    printf("|--pos = [%.2f, %.2f, %.2f]\n", obj -> pos[0], obj -> pos[1], obj -> pos[2]);
    printf("|--rot_global = [%.2f, %.2f, %.2f]\n", obj -> rot[0], obj -> rot[1], obj -> rot[2]);
    printf("|--rot_local  = [%.2f, %.2f, %.2f]\n", obj -> local_rot[0], obj -> local_rot[1], obj -> local_rot[2]);
    printf("|--v = [%.2f, %.2f, %.2f]\n", obj -> v[0], obj -> v[1], obj -> v[2]);
}


void print_children_ids(void* object, int delta_print)
{
    Object *obj = (Object*) object;
    for(int i=0;i<obj -> children; i++)
    {
        for(int j=0; j<delta_print; j++){printf("|--");}
        printf("%d", obj -> child[i] -> id);
        print_children_ids(obj -> child[i], delta_print+1);
    }
}


void print_map(void* map_in)
{
    Map *map = (Map*) map_in;
    printf("Map:\n|--Objects:\n");
    for(int i=0; i<map -> objects_cont; i++)
    {
        printf("|--|--id:%d\n", map -> objects[i] -> id);
        print_children_ids(map -> objects[i], 3);
    }
}


void move_object(void* object, float dx, float dy, float dz)
{
    Object *obj = (Object*) object;
    
    obj -> pos[0] += dx;
    obj -> pos[1] += dy;
    obj -> pos[2] += dz;
}

void place_object(void* object, float dx, float dy, float dz)
{
    Object *obj = (Object*) object;
    
    obj -> pos[0] = dx;
    obj -> pos[1] = dy;
    obj -> pos[2] = dz;
}

void rotate_object(void* object, float ax, float ay, float az)
{
    Object *obj = (Object*) object;
    obj -> local_rot[0] += ax;
    obj -> local_rot[1] += ay;
    obj -> local_rot[2] += az;
//    printf("rot_old=%lu\n", obj->rot);
    local_angles_to_global(obj->local_rot, obj->rot);
//    printf("rot_new=%lu\n", obj->rot);
}

void set_rot_object(void* object, float ax, float ay, float az)
{
    Object *obj = (Object*) object;
    obj -> local_rot[0] = ax;
    obj -> local_rot[1] = ay;
    obj -> local_rot[2] = az;
//    printf("rot_old=%lu\n", obj->rot);
    local_angles_to_global(obj->local_rot, obj->rot);
//    printf("rot_new=%lu\n", obj->rot);
}

//void add_child_object(void* ){}

void redact_plot(void* object, int plot, int new_x, int new_y, int new_z)
{
    Object* obj = (Object*) object;
    obj->plots[plot][0] = new_x;
    obj->plots[plot][1] = new_y;
    obj->plots[plot][2] = new_z;
}

int main()
{
    float plots_0[][3] = {{0, 0, 0}, {0, 1, 0}, {0, 1, 1}, {0, 0, 1}, {1, 0, 0}, {1, 1, 0}, {1, 1, 1}, {1, 0, 1}};
    int plots_0_len = 8;

    int polygons_0[][3] = {{0, 1, 2}, {0, 3, 2}, {4, 5, 6}, {4, 7, 6}};
    int polygons_0_len = 4;
    
    int texture[] = {0};
    
    void* test_obj_0 = create_object(plots_0_len, (char*) plots_0, polygons_0_len, (char*)polygons_0, 0, 0, 0, (char*)texture, (char*) polygons_0, 0);
    void* camera = create_object(plots_0_len, (char*) plots_0, polygons_0_len, (char*)polygons_0, 0, 0, 0, (char*) texture, (char*)polygons_0, 1);
    
    void* map = get_map_pointer();
    
    add_obj_to_map(map, test_obj_0);
    
    move_object(camera, -5, 0, 0);
    
    char* display_data = render_plots(map, camera, 200, 200, 50);
    
    rotate_object(test_obj_0, 10, 0, 0);

    display_data = render_plots(map, camera, 200, 200, 50);
}














