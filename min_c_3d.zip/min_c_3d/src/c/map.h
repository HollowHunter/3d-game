//#include <vector>

typedef struct Object Object;

struct Object
{
    int id;
    int plots_len;
    int poly_len;
    int istextured;
    int tex_id;
    int tex_plots_len;
    float pos[3];
    float rot[3];
    float local_rot[3];
    int mass;
    float v[3];
    int children;
    char isvisible;
    char iscamera;
    char isstatic;
    
    
    float** plots;
    int** polygons;
    int** surfaces;
    float** tex_plots;
    Object* *child;
};


struct Texture
{
    int size_x;
    int size_y;
    unsigned char* pixels;
};
typedef struct Texture Texture;


struct Map
{
    int objects_cont;
    int tex_cont;
    int g;
    Object* *objects;
    Texture* textures;
};

typedef struct PhisicMap PhisicMap;
typedef struct PhisicObject PhisicObject;

struct PhisicObject
{
    int plots_len;
    int poly_len;
    float sphere;
    float center;
    
    float** plots;
    float** polygons;
};

struct PhisicMap
{
    int objects_cont;
    PhisicObject* objects;
};

typedef struct Map Map;

struct Array_int
{
    int size;
    int* data;
};

struct Array_float
{
    int size;
    int* data;
};

//typedef struct Array_float Array_float;
//typedef struct Array_int Array_int;
