float zero_coord[3] = {0, 0, 0};


void display_object(unsigned char* display, float* z_buff, int size_x, int size_y, float scale, Object* obj, float rot_data[3][3], float cam_pos[3], Texture* textures, float delta[3])
{
//    printf("%lu\n----------\n", display);
    //printf("len=%d rot=%lu %f %f %f\n",obj->plots_len,obj -> rot,obj -> rot[0],obj -> rot[1],obj -> rot[2]);
    float *plots_3d[obj->plots_len];
    float obj_rot_data[3][3];
    get_rot_data(obj -> rot, obj_rot_data);
    Texture* tex;
    float inter_tex_x[3];
    float inter_tex_y[3];
    if(obj->istextured){tex = &(textures[obj->tex_id]);}
    //printf("test_0\n");
    float pos[3];
    pos[0] = obj->pos[0]+delta[0];
    pos[1] = obj->pos[1]+delta[1];
    pos[2] = obj->pos[2]+delta[2];
    for(int plot=0; plot < obj -> plots_len; plot++)
    {
        //{printf("test_1  malloc %ld\n",sizeof(float)*3);}
        float* new_plot = (float *) malloc(sizeof(float)*3);
        //if (new_plot==NULL) printf("plot=%d\n",plot);
        //{printf("test_2\n");}
        new_plot[0]=obj -> plots[plot][0];
        new_plot[1]=obj -> plots[plot][1];
        new_plot[2]=obj -> plots[plot][2];
        plots_3d[plot] = rotate_plot(move_plot(rotate_plot(new_plot, zero_coord, obj_rot_data), pos), cam_pos, rot_data);
    }
    int plots_2d[obj->plots_len][2];
    int no_plot[obj->plots_len];
    for(int plot=0; plot < obj -> plots_len; plot++)
    {
        if(plots_3d[plot][0]>0.1){
            plots_2d[plot][0] = (int) (plots_3d[plot][1]*scale/plots_3d[plot][0])+size_x/2;
            plots_2d[plot][1] = (int) (plots_3d[plot][2]*scale/plots_3d[plot][0])+size_y/2;
//            printf("[%.1f, %.1f, %.1f] == %d:%d\n", plots_3d[plot][0], plots_3d[plot][1], plots_3d[plot][2], plots_2d[plot][0], plots_2d[plot][1]);
//            free(plots_3d[plot]);
            no_plot[plot] = 0;
        }else{
            no_plot[plot] = 1;
        }
    }
    for(int p=0; p<obj -> poly_len; p++)
    {int* polygon = obj->polygons[p];
     int* surface = obj->surfaces[p];
        //printf("checkpoint_1 for started\n");
        if(!(no_plot[polygon[0]] || no_plot[polygon[1]] || no_plot[polygon[2]])){
            float polygon_2d[3][2] = {{plots_2d[polygon[0]][0], plots_2d[polygon[0]][1]},
                                      {plots_2d[polygon[1]][0], plots_2d[polygon[1]][1]},
                                      {plots_2d[polygon[2]][0], plots_2d[polygon[2]][1]}};
            float polygon_3d[3][3] = {{plots_3d[polygon[0]][0], plots_3d[polygon[0]][1], plots_3d[polygon[0]][2]},
                                      {plots_3d[polygon[1]][0], plots_3d[polygon[1]][1], plots_3d[polygon[1]][2]},
                                      {plots_3d[polygon[2]][0], plots_3d[polygon[2]][1], plots_3d[polygon[2]][2]}};
            float inter_k[3];
            float _1_x[3] = {1/polygon_3d[0][0], 1/polygon_3d[1][0], 1/polygon_3d[2][0]};
            if(obj->istextured)
            {
                float ctex_coords_x[3] = {obj->tex_plots[surface[0]][0]/polygon_3d[0][0],
                                          obj->tex_plots[surface[1]][0]/polygon_3d[1][0],
                                          obj->tex_plots[surface[2]][0]/polygon_3d[2][0]};
                
                float ctex_coords_y[3] = {obj->tex_plots[surface[0]][1]/polygon_3d[0][0],
                                          obj->tex_plots[surface[1]][1]/polygon_3d[1][0],
                                          obj->tex_plots[surface[2]][1]/polygon_3d[2][0]};
                
                Interpolate_triangle(polygon_2d, ctex_coords_x, inter_tex_x);
                Interpolate_triangle(polygon_2d, ctex_coords_y, inter_tex_y);
            }
            Interpolate_triangle(polygon_2d, _1_x, inter_k);
            //printf("\n[%f, %f, %f]\n", polygon_3d[0][0], polygon_3d[1][0], polygon_3d[2][0]);
            //printf("[%f, %f, %f]\n", _1_x[0], _1_x[1], _1_x[2]);
            //printf("[%f, %f, %f]\n\n", inter_k[0], inter_k[1], inter_k[2]);
            if(!IsPointsOnLine((int) polygon_2d[0][0], (int) polygon_2d[0][1],
                               (int) polygon_2d[1][0], (int) polygon_2d[1][1],
                               (int) polygon_2d[2][0], (int) polygon_2d[2][1]))
            {
                //printf("checkpoint_2 Interpolation end\n");
                int P0[2]={(int)polygon_2d[0][0], (int)polygon_2d[0][1]};
                int P1[2]={(int)polygon_2d[1][0], (int)polygon_2d[1][1]};
                int P2[2]={(int)polygon_2d[2][0], (int)polygon_2d[2][1]};
                //printf("checkpoint_2.1 Polygons copied\n");
//                int* save;
                ///printf("polygon_2d=[[%.1f, %.1f], [%.1f, %.1f], [%.1f, %.1f]]\n", polygon_2d[0][0], polygon_2d[0][1], polygon_2d[1][0], polygon_2d[1][1], polygon_2d[2][0], polygon_2d[2][1]);
                //printf("P0=[%d, %d]; P1=[%d, %d]; P2=[%d, %d];\n", P0[0], P0[1], P1[0], P1[1], P2[0], P2[1]);
                if(P1[1]<P0[1]){int save[2]={P0[0], P0[1]}; P0[0]=P1[0]; P0[1]=P1[1]; P1[0]=save[0]; P1[1]=save[1];}
                if(P2[1]<P0[1]){int save[2]={P0[0], P0[1]}; P0[0]=P2[0]; P0[1]=P2[1]; P2[0]=save[0]; P2[1]=save[1];}
                if(P2[1]<P1[1]){int save[2]={P2[0], P2[1]}; P2[0]=P1[0]; P2[1]=P1[1]; P1[0]=save[0]; P1[1]=save[1];}
                //printf("P0=[%d, %d]; P1=[%d, %d]; P2=[%d, %d];\n", P0[0], P0[1], P1[0], P1[1], P2[0], P2[1]);
                
                //printf("checkpoint_2.2 Plots sorted\n");
                //printf("interpolation_1: (%d, %d, %d, %d)\n", P0[1], P0[0], P1[1], P1[0]);
                
                int x01_size = (P1[1]-P0[1]+1);
                //printf("x01_size=%d\n", x01_size);
                int x01[x01_size];
                Interpolate_line(P0[1], P0[0], P1[1], P1[0], x01);
                
                //printf("checkpoint_2.2.1 Interpolation_1 ended\n");
                //printf("interpolation_2: (%d, %d, %d, %d)\n", P1[1], P1[0], P2[1], P2[0]);
                
                int x12_size = P2[1]-P1[1]+1;
                //printf("x12_size=%d\n", x12_size);
                int x12[x12_size];
                Interpolate_line(P1[1], P1[0], P2[1], P2[0], x12);
                
                //printf("checkpoint_2.2.2 Interpolation_2 ended\n");
                //printf("interpolation_3: (%d, %d, %d, %d)\n", P0[1], P0[0], P2[1], P2[0]);
                
                int x02_size = P2[1]-P0[1]+1;
                //printf("x02_size=%d\n", x02_size);
                int x02[x02_size];
                Interpolate_line(P0[1], P0[0], P2[1], P2[0], x02);
                
                //printf("checkpoint_2.2.3 Interpolation_3 ended\n");
                //printf("checkpoint_2.3 Second interpolation ended\n");
                
                int x012_size = x01_size+x12_size-1;
                int x012[x012_size];
                
                for(int i=0; i<x01_size-1; i++){x012[i]=x01[i];/*printf("%d:%d ", i, x01[i]);*/}
                
                //printf("| ");
                
                for(int i=0; i<x12_size; i++){x012[x01_size-1+i]=x12[i];/*printf("%d:%d ", x01_size+i-1, x12[i]);*/}
                
                //printf("\n");
                
                //for(int i=0; i<x012_size; i++){printf("%d:%d ", i, x012[i]);}
                
                //printf("\ncheckpoint_2.4 Small lines copied\ntest data_1:%d\ntest data_2:%d\n", x01[0], x12[0]);
                int m = x012_size/2;
                int *x_left, *x_right, x_right_size, x_left_size;
                if(x02[m] < x012[m]){
                    x_left = x02;
                    x_left_size = x02_size;
                    x_right = x012;
                    x_right_size = x012_size;
                }else{
                    x_left = x012;
                    x_left_size = x012_size;
                    x_right = x02;
                    x_right_size = x02_size;}
                
                //for(int i=0; i<x_left_size; i++){printf("%d ", x_left[i]);}printf("\n");
                //for(int i=0; i<x_right_size; i++){printf("%d ", x_right[i]);}printf("\n");
                
                //printf("checkpoint_3 Displaying nearly start\n");
                //printf("P0=[%d, %d];\nP1=[%d, %d];\nP2=[%d, %d];\n", P0[0], P0[1], P1[0], P1[1], P2[0], P2[1]);


                for(int y=P0[1]; y<=P2[1] && y<size_y; y++){//printf("y:%d%%\tx_start:%d; x_end:%d; index=%d<%d==%d\n", 100*(y-P0[1])/(P2[1]-P0[1]), x_left[y-P0[1]], x_right[y-P0[1]], y-P0[1], x_left_size, x_right_size);
                    for(int x=x_left[y-P0[1]]; x<=x_right[y-P0[1]] && x<size_x; x++)
                    {
                        if(y<0 || x<0 || y>=size_y || x>=size_x){continue;}
                        {
                            if(z_buff[y*size_x+x]<(inter_k[0]*x+inter_k[1]*y+inter_k[2])){
                                if(obj->istextured){
                                    z_buff[y*size_x+x] = (inter_k[0]*x+inter_k[1]*y+inter_k[2]);
                                    
                                    int tex_x = (int) ((tex->size_x)*(inter_tex_x[0]*x+inter_tex_x[1]*y+inter_tex_x[2]))/z_buff[y*size_x+x];
                                    int tex_y = (int) ((tex->size_y)*((inter_tex_y[0]*x+inter_tex_y[1]*y+inter_tex_y[2])))/z_buff[y*size_x+x];
                                    float tex_k_x = (inter_tex_x[0]*x+inter_tex_x[1]*y+inter_tex_x[2])/z_buff[y*size_x+x];
                                    float tex_k_y = (inter_tex_y[0]*x+inter_tex_y[1]*y+inter_tex_y[2])/z_buff[y*size_x+x];
                                    
                                    int d_rgb = (int) 1./z_buff[y*size_x+x]/2.+0.5;
                                    
                                    int col_r, col_g, col_b, alfa;
                                    if(0<=tex_x && 0<= tex_y && tex_x<tex->size_x && tex_y<tex->size_y)
                                    {
                                        col_r = tex->pixels[(tex_y*tex->size_x+tex_x)*4];
                                        col_g = tex->pixels[(tex_y*tex->size_x+tex_x)*4+1];
                                        col_b = tex->pixels[(tex_y*tex->size_x+tex_x)*4+2];
                                        alfa =  tex->pixels[(tex_y*tex->size_x+tex_x)*4+3];
                                    }else{
                                        col_r = 0;
                                        col_g = 0;
                                        col_b = 0;
                                        alfa = 255;
                                    }
                                    display[(y*size_x+x)*3]   = ((col_r*alfa)+(display[(y*size_x+x)*3]*(255-alfa)))/255;
                                    display[(y*size_x+x)*3+1] = ((col_g*alfa)+(display[(y*size_x+x)*3+1]*(255-alfa)))/255;
                                    display[(y*size_x+x)*3+2] = ((col_b*alfa)+(display[(y*size_x+x)*3+2]*(255-alfa)))/255;
                                    
                                }else{
                                    
                                    z_buff[y*size_x+x] = (inter_k[0]*x+inter_k[1]*y+inter_k[2]);
                                    int color = (int) 255*(inter_k[0]*x+inter_k[1]*y+inter_k[2]);
        //                            printf("dx=%f\t x = %d, size_x = %d; y = %d, size_y = %d;\n", inter_k[0]*x+inter_k[1]*y+inter_k[2], x, size_x, y, size_y);
                                    color = color>0?color:0;
                                    color = color<256?color:255;
                                    display[(y*size_x+x)*3]   = (unsigned char) color;
                                    display[(y*size_x+x)*3+1] = (unsigned char) color;
                                    display[(y*size_x+x)*3+2] = (unsigned char) color;
                                }
                            }
                        }
                    }//printf("\n");
                }
                
                //printf("polygon_2d=[[%.1f, %.1f], [%.1f, %.1f], [%.1f, %.1f]]\n", polygon_2d[0][0], polygon_2d[0][1], polygon_2d[1][0], polygon_2d[1][1], polygon_2d[2][0], polygon_2d[2][1]);
                //printf("P0=[%d, %d]; P1=[%d, %d]; P2=[%d, %d];\n", P0[0], P0[1], P1[0], P1[1], P2[0], P2[1]);
            }//else{printf("\nZero-space polygon\n\n");}
        }
    }
    for(int plot=0; plot < obj -> plots_len; plot++)
    {
        free(plots_3d[plot]);
    }
    float new_rot_data[3][3];
    matrix_multiply(obj_rot_data, rot_data, new_rot_data);
    for(int i=0; i<obj->children; i++)
    {
        display_object(display, z_buff, size_x, size_y, scale, obj->child[i], new_rot_data, cam_pos, textures, pos);
    }
}


char* render_plots(void* map_in, void* cam_in, int size_x, int size_y, int scale)
{
    Map *map = (Map*) map_in;
    Object *cam = (Object*) cam_in;
    if(cam -> iscamera==0){return (char*) "error";}
    float *cam_pos = cam -> pos;
    float rot_data[3][3];
    get_rot_data(cam->rot, rot_data);
    Texture* tex = map->textures;
    //printf("render plots malloc\n");
    unsigned char* screen = (unsigned char*) malloc(size_x*size_y*3);
    float* z_buff = (float*) malloc(sizeof(float)*size_x*size_y);
    //if (screen==NULL) printf("2!\n");
    for(int byte=0; byte<size_x*size_y*3; byte++){screen[byte]=0x1;}
    for(int num=0; num<size_x*size_y; num++){z_buff[num]=0;}
    #pragma omp parallel for
    for(int object=0; object < map->objects_cont; object++)
    {
//        printf("%lu\n", screen);
        //printf("object=%d map=%lu  %lu\n",object,map,map->objects[object]);
        display_object(screen, z_buff, size_x, size_y, scale, map->objects[object], rot_data, cam_pos, tex, zero_coord);
        //printf("\n\n\n\n\n");
    }
    
    //printf("END\nscreen_pos=%llx\n\n", screen);
    
    free(z_buff);
    return (char*) screen;
}
















