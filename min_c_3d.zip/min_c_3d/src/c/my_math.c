#define pi 3.1415926535897965f

inline float cosd(float angle){return (float) cos((double)angle*pi/180.);}
inline float sind(float angle){return (float) sin(angle*pi/180.);}
inline float tand(float angle){return (float) tan(angle*pi/180.);}

inline float atand(float data){return (float) atan(data)*180.f/pi;}
inline float atand2(float data1, float data2){return (float) atan2(data1, data2)*180.f/pi;}

inline void get_rot_data(float* ang, float res_matrix[3][3])
{    
    
    res_matrix[0][0] = cosd(ang[1])*cosd(ang[2]);
    res_matrix[0][1] = -cosd(ang[1])*sind(ang[2]);
    res_matrix[0][2] = sind(ang[1]);

    res_matrix[1][0] = sind(ang[0])*sind(ang[1])*cosd(ang[2]) + cosd(ang[0])*sind(ang[2]);
    res_matrix[1][1] = cosd(ang[0])*cosd(ang[2]) - sind(ang[0])*sind(ang[1])*sind(ang[2]);
    res_matrix[1][2] = -sind(ang[0]) * cosd(ang[1]);

    res_matrix[2][0] = sind(ang[0])*sind(ang[2]) - cosd(ang[0])*sind(ang[1])*cosd(ang[2]);
    res_matrix[2][1] = cosd(ang[0])*sind(ang[1])*sind(ang[2]) + sind(ang[0])*cosd(ang[2]);
    res_matrix[2][2] = cosd(ang[0]) * cosd(ang[1]);
    
}

inline float* rotate_plot(float plot[3], float center[3], float rot_data[3][3])
{
    float x, y, z;
    
    plot[0] -= center[0];
    plot[1] -= center[1];
    plot[2] -= center[2];
    
    /*y = rot_data[0] * plot[1] - rot_data[1] * plot[2];
    z = rot_data[1] * plot[1] + rot_data[0] * plot[2];
        plot[1]=y;plot[2]=z;
    x = rot_data[2] * plot[0] + rot_data[3] * plot[2];
    z = rot_data[2] * plot[2] - rot_data[3] * plot[0];
        plot[0]=x;plot[2]=z;
    x = rot_data[4] * plot[0] - rot_data[5] * plot[1];
    y = rot_data[4] * plot[1] + rot_data[5] * plot[0];
        plot[0]=x;plot[1]=y;*/
    
    x = rot_data[0][0]*plot[0]+rot_data[0][1]*plot[1]+rot_data[0][2]*plot[2];
    y = rot_data[1][0]*plot[0]+rot_data[1][1]*plot[1]+rot_data[1][2]*plot[2];
    z = rot_data[2][0]*plot[0]+rot_data[2][1]*plot[1]+rot_data[2][2]*plot[2];
    
    plot[0]=x; plot[1]=y; plot[2]=z;
    
    return plot;
}

inline float* move_plot(float plot[3], float coord[3])
{
    plot[0] += coord[0];
    plot[1] += coord[1];
    plot[2] += coord[2];
    return plot;
}

inline void local_angles_to_global(float local_angles[3], float old_global[3])
{
    old_global[2] = local_angles[2];
    old_global[1] = local_angles[0]*sind(local_angles[2])+local_angles[1]*cosd(local_angles[2]);
    old_global[0] = local_angles[1]*sind(local_angles[2])+local_angles[0]*cosd(local_angles[2]);
}

inline float v_len(float plot[3]){return sqrt(plot[0]*plot[0]+plot[1]*plot[1]+plot[2]*plot[2]);}


inline float Determinant_3d(float a[3][3]){return a[0][0]*a[1][1]*a[2][2]-a[0][0]*a[1][2]*a[2][1]-a[0][1]*a[1][0]*a[2][2]+a[0][1]*a[1][2]*a[2][0]+a[0][2]*a[1][0]*a[2][1]-a[0][2]*a[1][1]*a[2][0];}
inline float Determinant_2d(float a[2][2]){return a[0][0]*a[1][1]-a[1][0]*a[0][1];}


void Interpolate_triangle(float plots[3][2], float values[3], float *result)
{
    float m_1_t[3][3] = {{plots[0][0], plots[0][1], 1},
                         {plots[1][0], plots[1][1], 1},
                         {plots[2][0], plots[2][1], 1}};
    
    float det = Determinant_3d(m_1_t);
    //printf("\ndeterminant=%f\n", det);
    if(det==0){result[0]=0;result[1]=0;result[2]=0;return;}
    
    float a[3][3] = {{ (plots[1][1]-plots[2][1])/det, -(plots[1][0]-plots[2][0])/det,  ((plots[1][0]*plots[2][1])-(plots[2][0]*plots[1][1]))/det},
                     {-(plots[0][1]-plots[2][1])/det,  (plots[0][0]-plots[2][0])/det, -((plots[0][0]*plots[2][1])-(plots[2][0]*plots[0][1]))/det},
                     { (plots[0][1]-plots[1][1])/det, -(plots[0][0]-plots[1][0])/det,  ((plots[0][0]*plots[1][1])-(plots[1][0]*plots[0][1]))/det}};
    
    result[0] = values[0]*a[0][0]+values[1]*a[1][0]+values[2]*a[2][0];
    result[1] = values[0]*a[0][1]+values[1]*a[1][1]+values[2]*a[2][1];
    result[2] = values[0]*a[0][2]+values[1]*a[1][2]+values[2]*a[2][2];
    //printf("\nresult: [%f, %f, %f]\n\n", result[0], result[1], result[2]);
    return;
}


void Interpolate_line(int x_0, int y_0, int x_1, int y_1, int* result)
{
    //printf("interpolation started: (%d, %d, %d, %d)\n", x_0, y_0, x_1, y_1);
    if(x_0 == x_1){
        //printf("interpolation ended ");
        result[0]=y_0;
        //printf("...\n");
        return;}
    float k = ((float)(y_1-y_0))/((float)(x_1-x_0));
    //printf("k=%f\n", k);
    for(float x=0; x<=(float)(x_1-x_0); x++){/*printf("%.0f:%d ", k, (int)(k*x+y_0));*/  result[(int)x]=(int)(k*x+y_0);}
    //printf("end;\n");
    return;
}


inline int IsPointsOnLine(int x1, int y1, int x2, int y2, int x3, int y3) {
  return (x3 * (y2 - y1) - y3 * (x2 - x1) == x1 * y2 - x2 * y1);
}

inline void matrix_multiply(float a[3][3], float b[3][3], float res[3][3])
{
    res[0][0] = a[0][0]*b[0][0]+a[0][1]*b[1][0]+a[0][2]*b[2][0];
    res[0][1] = a[0][0]*b[0][1]+a[0][1]*b[1][1]+a[0][2]*b[2][1];
    res[0][2] = a[0][0]*b[0][2]+a[0][1]*b[1][2]+a[0][2]*b[2][2];
    
    res[1][0] = a[1][0]*b[0][0]+a[1][1]*b[1][0]+a[1][2]*b[2][0];
    res[1][1] = a[1][0]*b[0][1]+a[1][1]*b[1][1]+a[1][2]*b[2][1];
    res[1][2] = a[1][0]*b[0][2]+a[1][1]*b[1][2]+a[1][2]*b[2][2];
      
    res[2][0] = a[2][0]*b[0][0]+a[2][1]*b[1][0]+a[2][2]*b[2][0];
    res[2][1] = a[2][0]*b[0][1]+a[2][1]*b[1][1]+a[2][2]*b[2][1];
    res[2][2] = a[2][0]*b[0][2]+a[2][1]*b[1][2]+a[2][2]*b[2][2];
}












