#!/usr/bin/python3
# -*- coding: utf-8 -*-

import sys, pygame

# from pprint import pprint

# пути до модуля _test
#sys.path.append('.')
#sys.path.append('lib/')
sys.path.append('../../lib/')

# подключаем модуль скомпелированный cffi
import test_3d

INT_SIZE = test_3d.lib.get_int_size()
FLOAT_SIZE = test_3d.lib.get_float_size()

def to_int_array(data):
    res = []
    for num in data:
        pointer = test_3d.lib.int_to_bytes(num)
        res += test_3d.ffi.unpack(pointer, INT_SIZE)
        test_3d.lib.free_mem(pointer)
#        del(pointer)
#        print(test_3d.ffi.unpack(pointer, INT_SIZE))
    return bytes(res)

def to_float_array(data):
    res = []
    for num in data:
        pointer = test_3d.lib.float_to_bytes(num)
        res += test_3d.ffi.unpack(pointer, INT_SIZE)
        test_3d.lib.free_mem(pointer)
#        del(pointer)
#        print(test_3d.ffi.unpack(pointer, INT_SIZE))
    return bytes(res)

def to_int_list(data):
    res = []
    for i in range(0, len(data), INT_SIZE):
        res.append(0)
        for j in range(INT_SIZE-1, -1, -1):
#            print(i+j, len(data))
            res[-1]*=256
            res[-1]+=data[i+j]
    return res

def convert_2d(array):
    res = []
    for i in array:
        res.extend(i)
    return res

'''
test_3d
|--test_3d.ffi
|--|--test_3d.ffi.CData
|--|--test_3d.ffi.CType
|--|--test_3d.ffi.NULL
|--|--test_3d.ffi.RTLD_DEEPBIND
|--|--test_3d.ffi.RTLD_GLOBAL
|--|--test_3d.ffi.RTLD_LAZY
|--|--test_3d.ffi.RTLD_LOCAL
|--|--test_3d.ffi.RTLD_NODELETE
|--|--test_3d.ffi.RTLD_NOLOAD
|--|--test_3d.ffi.RTLD_NOW
|--|--test_3d.ffi.addressof
|--|--test_3d.ffi.alignof
|--|--test_3d.ffi.buffer
|--|--test_3d.ffi.callback
|--|--test_3d.ffi.cast
|--|--test_3d.ffi.def_extern
|--|--test_3d.ffi.dlclose
|--|--test_3d.ffi.dlopen
|--|--test_3d.ffi.errno
|--|--test_3d.ffi.error
|--|--test_3d.ffi.from_buffer
|--|--test_3d.ffi.from_handle
|--|--test_3d.ffi.gc
|--|--test_3d.ffi.getctype
|--|--test_3d.ffi.init_once
|--|--test_3d.ffi.integer_const
|--|--test_3d.ffi.list_types
|--|--test_3d.ffi.memmove
|--|--test_3d.ffi.new
|--|--test_3d.ffi.new_allocator
|--|--test_3d.ffi.new_handle
|--|--test_3d.ffi.offsetof
|--|--test_3d.ffi.release
|--|--test_3d.ffi.sizeof
|--|--test_3d.ffi.string
|--|--test_3d.ffi.typeof
|--|--test_3d.ffi.unpack
|--test_3d.lib
|--|--test_3d.lib.add_obj_to_map
|--|--test_3d.lib.add_texture_to_map
|--|--test_3d.lib.create_object
|--|--test_3d.lib.delete_object
|--|--test_3d.lib.float_to_bytes
|--|--test_3d.lib.free_mem
|--|--test_3d.lib.get_float_size
|--|--test_3d.lib.get_int_size
|--|--test_3d.lib.get_map_pointer
|--|--test_3d.lib.get_obj_id
|--|--test_3d.lib.int_to_bytes
|--|--test_3d.lib.move_object
|--|--test_3d.lib.print_map
|--|--test_3d.lib.print_obj
|--|--test_3d.lib.render_plots
|--|--test_3d.lib.rotate_object
'''

input('start')

#print('plots:')
plots_0 = [[0, 0, 0], [0, 1, 0], [0, 1, 1], [0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]]
plots_0_len = len(plots_0)
#print(plots_0)
plots_0 = convert_2d(plots_0)
#print(plots_0)
plots_0 = to_float_array(plots_0)
#print(plots_0)

#print('polygons:')
polygons_0 = [[0, 1, 2], [0, 3, 2], [4, 5, 6], [4, 7, 6]]
polygons_0_len = len(polygons_0)
#print(polygons_0)
polygons_0 = convert_2d(polygons_0)
#print(polygons_0)
polygons_0 = to_int_array(polygons_0)
#print(polygons_0, 'end', sep='\n')


cube_texture = pygame.image.load("Objects/cube_texture.png")
cube_texture_size = cube_texture.get_size()

test_tex_data = [0.752050, 0.749493,
                 0.752050, 0.999493,
                 0.502050, 0.999493,
                 0.502050, 0.749493,
                 1.000860, 0.749268,
                 1.000860, 0.999268,
                 0.750860, 0.999268,
                 0.750860, 0.749268]

test_tex_data = to_float_array(test_tex_data)

test_obj_0 = test_3d.lib.create_object(plots_0_len, plots_0, polygons_0_len, polygons_0, 1, 0, 8, test_tex_data, polygons_0, 0)
test_obj_1 = test_3d.lib.create_object(plots_0_len, plots_0, polygons_0_len, polygons_0, 0, 0, 0, bytes(), bytes(), 0)
cam = test_3d.lib.create_object(0, bytes(), 0, bytes(), 0, 0, 0, bytes(), bytes(), 1)

test_3d.lib.move_object(test_obj_0, 1, -0.5, -0.25)

input('continue')

Map = test_3d.lib.get_map_pointer()

test_3d.lib.add_texture_to_map(Map, cube_texture_size[0], cube_texture_size[1], pygame.image.tostring(cube_texture, 'RGBA'))
test_3d.lib.add_obj_to_map(Map, test_obj_0)
test_3d.lib.add_obj_to_map(Map, test_obj_1)

test_3d.lib.move_object(test_obj_1, 3, -1, -0.5)

test_3d.lib.print_obj(test_obj_0)

test_3d.lib.print_map(Map)

size_x = 500
size_y = 500
scale = 200

input('run')

display = pygame.display.set_mode((size_x, size_y))

test_3d.lib.move_object(cam, -1, 0, 0)

screen_got = test_3d.lib.render_plots(Map, cam, size_x, size_y, scale);

print("Python3 continue")

screen_translate = (test_3d.ffi.unpack(screen_got, (size_x*size_y*3)))

#print("screen_got:\n", screen_translate)
#print("size:", len(screen_translate), "==", (size_x*size_y*3))

img = pygame.image.fromstring(screen_translate, (size_x, size_y), 'RGB')
test_3d.lib.free_mem(screen_got)
display.blit(img, (0, 0))
pygame.display.flip()

input('1')
#display.fill((0, 0, 0))
test_3d.lib.move_object(cam, -5, 0, 0)

screen_got = test_3d.lib.render_plots(Map, cam, size_x, size_y, scale);

print("Python3 continue")

screen_translate = (test_3d.ffi.unpack(screen_got, (size_x*size_y*3)))

print("screen translated", type(screen_translate), len(screen_translate))

img = pygame.image.fromstring(screen_translate, (size_x, size_y), 'RGB')

print("img created")

test_3d.lib.free_mem(screen_got)

display.blit(img, (0, 0))
print("img blited")
pygame.display.flip()
print("screen updated")
test_3d.lib.print_obj(test_obj_0)

input('2')
#display.fill((0, 0, 0))
test_3d.lib.move_object(cam, 5, 0, 0)
test_3d.lib.rotate_object(test_obj_0, 0, 0, 0)
screen_got = test_3d.lib.render_plots(Map, cam, size_x, size_y, scale);

print("Python3 continue")

img = pygame.image.fromstring(test_3d.ffi.unpack(screen_got, (size_x*size_y*3)), (size_x, size_y), 'RGB')

test_3d.lib.free_mem(screen_got)

display.blit(img, (0, 0))
pygame.display.flip()

test_3d.lib.print_obj(test_obj_0)

input('3')

fps_clock = pygame.time.Clock()

test_3d.lib.rotate_object(test_obj_0, 0, 0, 0)
test_3d.lib.move_object(cam, 0, 0, 0)

for i in range(360*5):
    for event in pygame.event.get():
        if event.type==pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                wait = True
                while wait:
                        for event in pygame.event.get():
                            if event.type==pygame.MOUSEBUTTONDOWN:
                                if event.button == 2:
                                    wait=False
    test_3d.lib.rotate_object(test_obj_0, 0, 0, 1)
    screen_got = test_3d.lib.render_plots(Map, cam, size_x, size_y, scale);

    img = pygame.image.fromstring(test_3d.ffi.unpack(screen_got, (size_x*size_y*3)), (size_x, size_y), 'RGB')
    test_3d.lib.free_mem(screen_got)
    display.blit(img, (0, 0))
    pygame.display.flip()
#    fps_clock.tick(30)

#test_3d.lib.delete_object(test_obj_0)

input('end')


exit()

class m_str:
    def __init__(self, name=''):
        self.name = name
    def __add__(self, other):
        if isinstance(other, (int, float)):
            if other == 0:
                return self
            return m_str(f'({self.name}+{other})')
        return m_str(f'({self.name}+{other.name})')
    def __sub__(self, other):
        if isinstance(other, (int, float)):
            if other == 0:
                return self
            return m_str(f'({self.name}-{other})')
        return m_str(f'({self.name}-{other.name})')
    def __mul__(self, other):
        if isinstance(other, (int, float)):
            if other == 1:
                return self
            elif other == 0:
                return m_str()
            return m_str(f'{self.name}*{other}')
        return m_str(f'{self.name}*{other.name}')
    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            if other == 1:
                return self
            elif other == 0:
                return m_str()
            return m_str(f'{self.name}/{other}')
        return m_str(f'{self.name}/{other.name}')
    def __repr__(self):
        return self.name

'''
(cosd(angles[1])*cosd(angles[2]))
(cosd(angles[1])*-sind(angles[2]))
sind(angles[1])

sind(angles[0])*sind(angles[1])*cosd(angles[2]) + cosd(angles[0])*sind(angles[2]) 
cosd(angles[0])*cosd(angles[2]) - sind(angles[0])*sind(angles[1])*sind(angles[2])
-sind(angles[0]) * cosd(angles[1])

-cosd(angles[0])*sind(angles[1])*cosd(angles[2]) + sind(angles[0])*sind(angles[2])
cosd(angles[0])*sind(angles[1])*sind(angles[2]) + sind(angles[0])*cosd(angles[2])
cosd(angles[0])*cosd(angles[1])
'''














