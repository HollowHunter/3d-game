#!/usr/bin/python3

Determinant_3d = lambda a: a[0][0]*a[1][1]*a[2][2]-a[0][0]*a[1][2]*a[2][1]-a[0][1]*a[1][0]*a[2][2]+a[0][1]*a[1][2]*a[2][0]+a[0][2]*a[1][0]*a[2][1]-a[0][2]*a[1][1]*a[2][0]
Determinant_2d = lambda a: a[0][0]*a[1][1]-a[1][0]*a[0][1]

def Interpolate_triangle(plots):
    (x0, y0), (x1, y1), (x2, y2) = plots
    matrix_1 = [[x0, x1, x2],\
                [y0, y1, y2],\
                [1,  1,  1]]
    det_1 = Determinant_3d(matrix_1)
    matrix_1_t = [[matrix_1[y][x] for y in range(3)]for x in range(3)]
    matrix_1_t_md = [[Determinant_2d([[matrix_1_t[xx][yy] for yy in range(3) if not(xx==x or yy==y)] for xx in range(3) if [matrix_1_t[xx][yy] for yy in range(3) if not(xx==x or yy==y)]]) for y in range(3)]for x in range(3)]
    print(*matrix_1, sep='\n', end='\n\n')
    print(*matrix_1_t, sep='\n', end='\n\n')
    print(*matrix_1_t_md, sep='\n', end='\n\n')
    matrix_1_1 = [[matrix_1_t_md[x][y]/det_1 for y in range(3)]for x in range(3)]
    print(*matrix_1_1, sep='\n', end='\n\n')
    a = matrix_1_1
    result = lambda x, y, v: [[(a[0][0]*x+a[0][1]*y+a[0][2])*v[0], (a[0][0]*x+a[0][1]*y+a[0][2])*v[1], (a[0][0]*x+a[0][1]*y+a[0][2])*v[2]],\
                              [(a[1][0]*x+a[1][1]*y+a[1][2])*v[0], (a[1][0]*x+a[1][1]*y+a[1][2])*v[1], (a[1][0]*x+a[1][1]*y+a[1][2])*v[2]],\
                              [(a[2][0]*x+a[2][1]*y+a[2][2])*v[0], (a[2][0]*x+a[2][1]*y+a[2][2])*v[1], (a[2][0]*x+a[2][1]*y+a[2][2])*v[2]]]
    return result
    

interpolation_func = Interpolate_triangle([[0, 0], [100, 0], [0, 100]])

print(interpolation_func(20, 10, [0, 0, 255]))
