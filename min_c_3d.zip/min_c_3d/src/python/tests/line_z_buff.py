#!/usr/bin/python3

import pygame
from math import ceil, sqrt

screen = pygame.display.set_mode((1000, 500))
screen.fill(0xffffff, (500, 0, 1, 500))
pygame.display.flip()

line = [[10, 50], [110, 75]]
plot = [60, 200]

def Interpolate (line):
    (x0, y0), (x1, y1) = line
    k = sqrt((x1-x0)**2 + (y1-y0)**2)
    return [[int(x0*t+x1*(1-t)), int(y0*t+y1*(1-t))] for t in map(lambda x: x/k, range(ceil(k+0.5)))]

draw_plot = lambda col, x, y: [screen.fill(col, (x+750, -y+250, 1, 1)), pygame.display.flip()]

k = 100

Proect = lambda line: list(map(lambda p: k*(p[0]-plot[0])/(p[1]-plot[1]), Interpolate(line)))



[[screen.fill(0xff4040, (x, y, 1, 1)), pygame.display.update((x-1, y-1, 3, 3))] for x, y in Interpolate(line)]
pygame.draw.circle(screen, 0x40ff40, plot, 2)
pygame.display.flip()

screen.fill(0x303030, (750, 0, 1, 500))
screen.fill(0x303030, (500, 250, 500, 1))

[draw_plot(0xff7700, x, y) for x, y in enumerate(Proect(line))]
[draw_plot(0xff0000, x, y) for x, y in enumerate([i[0] for i in Interpolate(line)])]
[draw_plot(0x00ff00, x, y) for x, y in enumerate([i[1] for i in Interpolate(line)])]

delta_buf = -line[0][1]+plot[1]
# z/x
# x=?
# 

convert = lambda x: x+delta_buf

[draw_plot(0x0000ff, x, y) for x, y in zip(Proect(line), map(convert, Proect(line)))]

[draw_plot(0x00ffff, x, y) for x, y in zip(Proect(line), map(lambda p: sqrt((p[0]-plot[0])**2+(p[1]-plot[1])**2), Interpolate(line)))]

input('end')
pygame.quit()
