#!/usr/bin/python3

import pygame
from math import sqrt, ceil
from random import randint

screen = pygame.display.set_mode((500, 500))

triangle = [[10, 10], [100, 0], [0, 100]]

def Interpolate (i0, d0, i1, d1):
    if i0==i1:
        return [d0]
    a = (d1 - d0) / (i1 - i0)
    return [round(d0 + a*(i-i0)) for i in range(i0, i1+1)]

color = lambda i, max_i: (int(255*i/max_i)if(i<=max_i)else(255), int(255-255*i/max_i)if(i<=max_i)else(255), 0if(i<=max_i)else(255)) if max_i>0 else 0

Determinant_3d = lambda a: a[0][0]*a[1][1]*a[2][2]-a[0][0]*a[1][2]*a[2][1]-a[0][1]*a[1][0]*a[2][2]+a[0][1]*a[1][2]*a[2][0]+a[0][2]*a[1][0]*a[2][1]-a[0][2]*a[1][1]*a[2][0]
Determinant_2d = lambda a: a[0][0]*a[1][1]-a[1][0]*a[0][1]

def Interpolate_triangle(plots, values):
    (x0, y0), (x1, y1), (x2, y2) = plots
    matrix_1_t = [[x0, y0, 1],\
                  [x1, y1, 1],\
                  [x2, y2, 1]]
    det = Determinant_3d(matrix_1_t)
    a = [[(plots[1][1]-plots[2][1])/det, -(plots[1][0]-plots[2][0])/det,  ((plots[1][0]*plots[2][1])-(plots[2][0]*plots[1][1]))/det],\
        [-(plots[0][1]-plots[2][1])/det,  (plots[0][0]-plots[2][0])/det, -((plots[0][0]*plots[2][1])-(plots[2][0]*plots[0][1]))/det],\
        [ (plots[0][1]-plots[1][1])/det, -(plots[0][0]-plots[1][0])/det,  ((plots[0][0]*plots[1][1])-(plots[1][0]*plots[0][1]))/det]]
    v = values
    k1 = v[0]*a[0][0]+v[1]*a[1][0]+v[2]*a[2][0]
    k2 = v[0]*a[0][1]+v[1]*a[1][1]+v[2]*a[2][1]
    k3 = v[0]*a[0][2]+v[1]*a[1][2]+v[2]*a[2][2]
    result = lambda x, y: x*k1+y*k2+k3
    return result

def space(a, b, c):
    a, b, c = sqrt((a[0]-b[0])**2+(a[1]-b[1])**2), sqrt((a[0]-c[0])**2+(a[1]-c[1])**2), sqrt((c[0]-b[0])**2+(c[1]-b[1])**2)
    p = (a+b+c)/2
    return ceil(sqrt(p*(p-a)*(p-b)*(p-c)))

def DrawFilledTriangle (P0, P1, P2):
    pygame.draw.polygon(screen, 0xf0760f, (P0, P1, P2))
    # Сортировка точек так, что y0 <= y1 <= y2
    
    pygame.display.flip()
    delta = [-P0[0], -P0[1]]
    P0 = [P0[0]-delta[0], P0[1]-delta[1]]
    P1 = [P1[0]-delta[0], P1[1]-delta[1]]
    P2 = [P2[0]-delta[0], P2[1]-delta[1]]
    
    if P1[1] < P0[1]:
        P1, P0 = P0, P1
    if P2[1] < P0[1]:
        P2, P0 = P0, P2
    if P2[1] < P1[1]:
        P2, P1 = P1, P2
    
    (x0, y0), (x1, y1), (x2, y2) = P0, P1, P2

    # Вычисление координат x рёбер треугольника
    x01 = Interpolate(y0, x0, y1, x1)
    x12 = Interpolate(y1, x1, y2, x2)
    x02 = Interpolate(y0, x0, y2, x2)

    # Конкатенация коротких сторон
    x012 = x01[:-1] + x12

    # Определяем, какая из сторон левая и правая
    m = len(x012) // 2
    if x02[m] < x012[m]:
        x_left = x02
        x_right = x012
    else:
        x_left = x012
        x_right = x02

    # Отрисовка горизонтальных отрезков
    i=0
    max_i = space(P0, P1, P2)
    for y in range(y0, y2+1):
        for x in range(x_left[y - y0], x_right[y - y0]+1):
            screen.fill(color(i, max_i), (x+delta[0], y+delta[1], 1, 1))
            i+=1
            pygame.display.update((x-1+delta[0], y-1+delta[1], 3, 3))

def display_triangle_func(P0, P1, P2):
    pygame.draw.polygon(screen, 0xf0760f, (P0, P1, P2))
    pygame.display.flip()
    values_r = [0, 0, 255]
    values_g = [0, 255, 0]
    values_b = [255, 0, 0]
    color_func = [Interpolate_triangle([P0, P1, P2], values_r), Interpolate_triangle([P0, P1, P2], values_g), Interpolate_triangle([P0, P1, P2], values_b)]
    bound = lambda a: int(a) if 0<=(a)<=255 else 32
    color_ = lambda x, y: [bound(color_func[0](x, y)), bound(color_func[1](x, y)), bound(color_func[2](x, y))]
    for x in range(500):
        for y in range(500):
#            print(*(color_func(x, y, values)), sep='\n', end='\n\n')
            screen.fill(color_(x, y), (x, y, 1, 1))
        pygame.display.update((x, 0, 1, 500))
#    pygame.draw.polygon(screen, 0xf0760f, (P0, P1, P2))
#    pygame.display.flip()

DrawFilledTriangle([100, 100], [200, 100], [300, 100])

for i in range(10):
    DrawFilledTriangle((randint(1, 500), randint(1, 500)), (randint(1, 500), randint(1, 500)), (randint(1, 500), randint(1, 500)))

input('end')

pygame.quit()
