import pygame

screen = pygame.display.set_mode((500, 500))

class Vector:
    def __init__(self, array):
        self.data = array
    def getdata(self):
        return self.data
    def __add__(self, other):
        if isinstance(other, Vector):
            return Vector([a+b for a, b in zip(self.getdata(), other.getdata())])
        elif isinstance(other, (int, float)):
            return Vector([i+other for i in self.data])
    def __truediv__(self, num):
        if isinstance(num, (int, float)):
            return Vector([i/num for i in self.data])
    def __mul__(self, num):
        if isinstance(num, (int, float)):
            return Vector([i*num for i in self.data])
    def __len__(self):
        return len(self.data)
    def get(self, elem):
        return self.data[elem]
    def __repr__(self):
        return 'Vector: '+str(self.data)
    def __neg__(self):
        return Vector([-i for i in self.data])
    def __sub__(self, other):
        if isinstance(other, Vector):
            return Vector([a-b for a, b in zip(self.getdata(), other.getdata())])
        elif isinstance(other, (int, float)):
            return Vector([i-other for i in self.data])

while True:
    sqr = [[], [], [], []]
    sqr[0] = Vector(list(map(int, input().split())))
    if len(sqr[0])<2:
        exit()
    sqr[1] = Vector(list(map(int, input().split())))
    sqr[2] = Vector(list(map(int, input().split())))
    sqr[3] = Vector(list(map(int, input().split())))
    
    pygame.draw.polygon(screen, (0x0, 0x0, 0xff), [i.getdata() for i in sqr])
    
#    sqr[1]-=sqr[0]
#    sqr[2]-=sqr[0]
#    sqr[3] = Vector([0, 0])
    
    print(sqr)

    n = 100
    
    
    for k1 in map(lambda x: x/n, range(n+1)):
        for k2 in map(lambda x: x/n, range(n+1)):
            
            plot = Vector([0, 0])
            
            
            plot += (sqr[0]*k1+sqr[1]*(1-k1))*k2
            plot += (sqr[3]*k1+sqr[1]*(1-k1))*(1-k2)
            plot += (sqr[0]*k2+sqr[2]*(1-k2))*k1
            plot += (sqr[3]*k2+sqr[2]*(1-k2))*(1-k1)
#            plot /= 2
            plot -= sqr[0]
            
            screen.fill((int(255*k1), int(255*k2), 0), (round(plot.get(0)), round(plot.get(1)), 1, 1))
    pygame.display.flip()


















