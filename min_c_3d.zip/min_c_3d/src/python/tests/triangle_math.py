import pygame

triangle = [[0, 10], [150, 10], [50, 60]]

screen = pygame.display.set_mode((500, 500))

pygame.draw.polygon(screen, (64, 64, 64), triangle)

pygame.display.flip()

x_0, y_0 = triangle[0]
triangle[0][0] -= x_0
triangle[1][0] -= x_0
triangle[2][0] -= x_0
triangle[0][1] -= y_0
triangle[1][1] -= y_0
triangle[2][1] -= y_0

n=20

for k1_for in range(n+1):
    for k2_for in range(n+1):
        for k3_for in range(n+1):
            k1, k2, k3 = k1_for/n, k2_for/n, k3_for/n
            x = triangle[0][0]*k1+triangle[1][0]*(1-k1)
            x+= triangle[0][0]*k2+triangle[2][0]*(1-k2)
            x+= triangle[1][0]*k3+triangle[2][0]*(1-k3)
            y = triangle[0][1]*k1+triangle[1][1]*(1-k1)
            y+= triangle[0][1]*k2+triangle[2][1]*(1-k2)
            y+= triangle[1][1]*k3+triangle[2][1]*(1-k3)
            screen.fill((int(255*k1), int(255*k2), int(255*k3)), (round(x+x_0), round(y+y_0), 1, 1))
            pygame.display.flip()
            
input('end')
