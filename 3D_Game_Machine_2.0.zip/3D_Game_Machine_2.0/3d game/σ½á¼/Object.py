from хлам.Math import Math


class DynamicObject:
    def __init__(self, name, map_, center=(0, 0, 0), mass=0):
        self.name = name
        self.plots = map_[0]
        self.polygons = map_[1]
        self.center = center
        self.mass = 0
        self.rotation = (0, 0, 0)
        self.coordinates_on_parent = (0, 0, 0)
        self.math = Math()
        self.child_obj = []
        self.mass = 0
        self.update = 0
        self.parent = 'map'

    def set_parent(self, obj):
        self.parent = obj

    def rotate(self, angles):
        self.rotation = self.math.m_sum(self.rotation, angles)
        a, b, c = self.rotation
        a %= 360
        b %= 360
        c %= 360
        self.rotation = (a, b, c)

    def get_local_rotation(self):
        return self.rotation

    def get_coordinates_on_parent(self):
        return self.coordinates_on_parent

    def get_parent(self):
        return self.parent

    def move(self, delta):
        self.coordinates_on_parent = self.math.m_sum(self.coordinates_on_parent, delta)

    def add_child(self, obj):
        self.child_obj.append(obj)
        obj.set_parent(self)

    def get_render_data(self):
        plots = self.math.rotate_plots(self.plots, self.math.rotate_data(self.rotation), self.center)
        plots = [self.math.m_sum(plot, self.coordinates_on_parent) for plot in plots]
        data_self = (plots, self.polygons)
        data_child = []
        for obj in self.child_obj:
            for struct in obj.get_render_data():
                (plots, polygons) = struct
                plots = self.math.rotate_plots(plots, self.math.rotate_data(self.rotation), self.center)
                plots = [self.math.m_sum(plot, self.coordinates_on_parent) for plot in plots]
                data_child.append((plots, polygons))
        return [data_self] + data_child

    def connect(self, func):
        self.update = func

    def FrameUpdate(self):
        if self.update:
            self.update()

if __name__ == '__main__':
    sqr1 = DynamicObject('sqr1', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]])
    sqr1.move((5, 0, 0))
    sqr1.rotate((0, 90, 0))
    sqr2 = DynamicObject('sqr2', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]])
    sqr1.add_child(sqr2)
    sqr2.move((-1, 0, 0))
    a = sqr1.get_render_data()
    exit()