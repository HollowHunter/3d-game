from хлам.Math import Math
from хлам.Object import DynamicObject
from хлам.Phisics import Phisics
from хлам.Renderer import Renderer

phisics = Phisics()
math = Math()
renderer = Renderer((640, 480), phisics.get_map())
sqr1 = DynamicObject('sqr1', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]])
phisics.add_object(sqr1)
sqr1.move((5, 0, 0))
# sqr1.rotate((45, 30, 90))
# sqr1.rotate((45, 30, 90))
sqr2 = DynamicObject('sqr2', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]], (0, 0, 0))
sqr1.add_child(sqr2)
sqr2.move((-1, 0, 0))

sqr3 = DynamicObject('sqr3', [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]])
sqr1.add_child(sqr3)
sqr3.move((-2, 0, 0))

res = renderer.calc_pre_render()
renderer.render(res)
renderer.pygame.display.flip()

clock = renderer.pygame.time.Clock()

run = True

cam_v = (0, 0, 0)
cam_pos = (0, 0, 0)
cam_angles = (0, 0, 0)

v_sum = lambda one, two: tuple(map(sum, zip(one, two)))
speed = 0.1

while run:
    for event in renderer.pygame.event.get():
        if event.type == renderer.pygame.QUIT:
            run = False
        elif event.type == renderer.pygame.KEYDOWN:
            print(cam_pos)
            key = event.key
            if key == renderer.pygame.K_SPACE:
                cam_pos = v_sum(cam_pos, (0, 0, speed * 1))
            elif key == renderer.pygame.K_LSHIFT or key == renderer.pygame.K_RSHIFT:
                cam_pos = v_sum(cam_pos, (0, 0, -speed * 1))
            elif key in (renderer.pygame.K_UP, renderer.pygame.K_w):
                cam_pos = v_sum(cam_pos, ((speed * Math.cosd(None, cam_angles[2]) * 1), -speed * Math.sind(None, cam_angles[2]), 0))
                # print(((1e-5*cosd(cam_angles[2])*d_t), 1e-5*Math.sind(None, cam_angles[2])*d_t, 0), ((1e-5*cosd(cam_angles[2])*d_t)**2 + (1e-5*Math.sind(None, cam_angles[2])*d_t)**2)**0.5 - 1e-5*d_t)
            elif key in (renderer.pygame.K_DOWN, renderer.pygame.K_s):
                cam_pos = v_sum(cam_pos, (-(speed * Math.cosd(None, cam_angles[2]) * 1), speed * Math.sind(None, cam_angles[2]) * 1, 0))
            elif key in (renderer.pygame.K_RIGHT, renderer.pygame.K_d):
                cam_pos = v_sum(cam_pos, ((speed * Math.sind(None, cam_angles[2]) * 1), speed * Math.cosd(None, cam_angles[2]) * 1, 0))
            elif key in (renderer.pygame.K_LEFT, renderer.pygame.K_a):
                cam_pos = v_sum(cam_pos, (-(speed * Math.sind(None, cam_angles[2]) * 1), -speed * Math.cosd(None, cam_angles[2]) * 1, 0))
            elif key == renderer.pygame.K_ESCAPE:
                running = False
            renderer.cam_place(cam_pos)
    sqr1.rotate((0, 0, 2))
    sqr2.rotate((3, 0, 0))
    sqr3.rotate((0, 0, 0))
    sqr3.move((0.05,0,0))
    # renderer
    res = renderer.calc_pre_render()
    renderer.render(res)
    renderer.pygame.display.flip()
    clock.tick(20)

renderer.pygame.quit()
