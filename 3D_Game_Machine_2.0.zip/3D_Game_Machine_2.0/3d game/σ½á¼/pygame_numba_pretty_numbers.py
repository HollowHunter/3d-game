#!/usr/bin/python3

from numba import njit, jit
from numba import int_
from math import sin, cos, degrees, radians
import pygame


# @njit
def calc_numbers(n_max):
    res = [i for i in range(2, int(n_max))]
    res_old = [0]
    n = 0
    stop = False
    while res != res_old:
        n+=1
        res_old = res.copy()
        res = res[:n] + [i for i in res[n:] if i%res[n-1] != 0]
        #print(res, res[n-1])
    return [1]+res
        

#calc_numbers(3)

# @njit
def calc_prerender(plots, k, dx, dy):
    res = [[0, 0]]
    for plot in plots:
        res.append([int(cos(plot)*plot*k+dx), int(sin(plot)*plot*k+dy)])
    return res



print('start')
print(calc_numbers(3), calc_prerender([1, 2], 1.0, 1, 1))
print('main')

max_ = 200
k = 2


pygame.init()

screen = pygame.display.set_mode((500, 500))


while pygame.QUIT not in [i.type for i in pygame.event.get()]:
    screen.fill((0, 0, 0))
    plots = calc_numbers(max_)
    k *= 0.99
    max_ *= 1.01
    pixels = calc_prerender(plots, k, 250, 250)
    print(len(plots), max_)
    for pixel in pixels:
        screen.fill((160, 160, 160), (pixel[0], pixel[1], 1, 1))

    pygame.display.flip()



pygame.quit()
