from copy import deepcopy
import pygame


class Board:
    # создание поля
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        # значения по умолчанию
        self.left = 10
        self.top = 10
        self.cell_size = 30

        self.old_cell = None

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, holst):
        color = [pygame.Color(0, 0, 0), pygame.Color(0, 255, 0)]
        for i in range(self.width):
            for j in range(self.height):
                pygame.draw.rect(holst, (100, 100, 100), [self.cell_size * i + self.left,
                                                          self.cell_size * j + self.top,
                                                          self.cell_size, self.cell_size], 1)
                pygame.draw.rect(holst, color[self.board[j][i]], [self.cell_size * i + self.left + 1,
                                                          self.cell_size * j + self.top + 1,
                                                          self.cell_size - 2, self.cell_size - 2])

    def get_cell(self, mouse_pos):
        cell_pos = ((mouse_pos[0] - self.left) // self.cell_size,
                    (mouse_pos[1] - self.top) // self.cell_size)
        return cell_pos if cell_pos[0] in range(self.width) and \
                           cell_pos[1] in range(self.height) else None

    def on_click(self, cell_pos):
        if cell_pos != None:
            self.board[cell_pos[1]][cell_pos[0]] = (self.board[cell_pos[1]][cell_pos[0]] + 1) % 2

    def get_click(self, mouse_pos, is_click=False):
        cell = self.get_cell(mouse_pos)
        if self.old_cell != cell or is_click:
            self.on_click(cell)
        self.old_cell = cell

class Life(Board):
    def __init__(self, widht, height):
        super().__init__(widht, height)

    def clean(self):
        self.board = [[0] * self.width for _ in range(self.height)]

    def next_move(self):
        new_board = [[0] * self.width for _ in range(self.height)]
        for x in range(self.width):
            for y in range(self.height):
                count = self.get_count_of_cell(x, y)
                # if count in (2, 3):
                #     new_board[y][x] = 1
                # elif count < 2 and count > 3:
                #     new_board[y][x] = 0
                if count == 3:
                    new_board[y][x] = 1
                    print(new_board[y][x], 'life')
                elif count < 2 and count > 3:
                    new_board[y][x] = 0
                    print(new_board[y][x], 'dead')
                elif count in (2,) and self.board[y][x]:
                    new_board[y][x] = 1
                    print(new_board[y][x], 'non')
        self.board = new_board



    def get_count_of_cell(self, x, y):
        location = [(-1, -1), (0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0)]
        count_cell = 0
        for elem in location:
            if x + elem[0] >= 0 and y + elem[1] >= 0 and x + elem[0] \
                    <= self.width - 1 and y + elem[1] <= self.height - 1:
                if self.board[y + elem[1]][x + elem[0]] == 1:
                    count_cell += 1
        return count_cell


fps = 10
pygame.init()
n, m = 15, 15
# n, m = 50, 50
left, top, cell_size = 15, 15, 15
size = left * 2 + n * cell_size, top * 2 + m * cell_size
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Игра жизнь')
board = Life(n, m)
board.set_view(left, top, cell_size)
clock = pygame.time.Clock()

is_run = False
is_clicked = False
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == 32:
                is_run = not is_run
                print(is_run)
        if event.type == pygame.MOUSEBUTTONDOWN:
            print(event.__dict__)
            if event.button == 1:
                board.get_click(event.pos, True)
                is_clicked = True
            elif event.button == 3:
                is_run = not is_run
                print(is_run)
            elif event.button == 2:
                board.clean()
                is_run = False
            elif event.button == 4:
                fps += 1
            elif event.button == 5:
                fps -= 1
        if event.type == pygame.MOUSEBUTTONUP:
            is_clicked = False
        if event.type == pygame.MOUSEMOTION:
            if is_clicked:
                board.get_click(event.pos)
    screen.fill((0, 0, 0))
    if is_run:
        board.next_move()
    board.render(screen)
    clock.tick(fps)
    pygame.display.flip()
pygame.quit()