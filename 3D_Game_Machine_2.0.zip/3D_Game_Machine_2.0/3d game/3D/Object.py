class DynamicObject:
    def __init__(self, game, name, map_, center=(0, 0, 0), mass=0):
        self.iscamera = False
        self.name = name
        self.plots = map_[0]
        self.polygons = map_[1]
        self.center = center
        self.mass = 0
        self.rotation = [0, 0, 0]
        self.coordinates_on_parent = (0, 0, 0)
        self.game = game
        self.math = game.Math
        self.child_obj = []
        self.mass = 0
        self.update = bool
        self.parent = 'map'

        self.new_rottation = [0, 0, 0]
        self.rot_speed = [0, 0, 0]

    def set_parent(self, obj):
        self.parent = obj

    def rotate(self, angles): # изменено
        self.rotation = self.math.m_sum(self.rotation, angles)
        a, b, c = self.rotation
        a %= 360
        b %= 360
        c %= 360
        self.rotation = [a, b, c]

    def get_local_rotation(self):
        return self.rotation

    def get_coordinates_on_parent(self):
        return self.coordinates_on_parent

    def get_parent(self):
        return self.parent

    def move(self, delta):
        self.coordinates_on_parent = self.math.m_sum(self.coordinates_on_parent, delta)

    def add_child(self, obj):
        self.child_obj.append(obj)
        obj.set_parent(self)

    def set_pos(self, pos):
        self.coordinates_on_parent = pos

    def set_rotation(self, rot):
        self.rotation = rot

    def get_render_data(self):
        plots = self.math.rotate_plots(self.plots, self.math.rotate_data(self.rotation), self.center)
        plots = [self.math.m_sum(plot, self.coordinates_on_parent) for plot in plots]
        data_self = (plots, self.polygons)
        data_child = []
        for obj in self.child_obj:
            if not obj.iscamera:
                for struct in obj.get_render_data():
                    (plots, polygons) = struct
                    plots = self.math.rotate_plots(plots, self.math.rotate_data(self.rotation), self.center)
                    plots = [self.math.m_sum(plot, self.coordinates_on_parent) for plot in plots]
                    data_child.append((plots, polygons))
        return [data_self] + data_child

    def connect(self, EventSystem, func):
        self.update = func
        EventSystem.add_object_func(self.update)

    def rot_to(self, target_angels, speed, indx):
        # print(-4 in range(-speed[indx], speed[indx]))
        if self.rotation[indx] != target_angels:
            arr = [0, 0, 0]
            arr[indx] = speed
            speed = tuple(arr)
            self.rotate(speed)
            if -abs(speed[indx]) < abs(self.rotation[indx] - target_angels) < abs(speed[indx]):
                self.rotation[indx] = target_angels
                self.rot_speed = [0,0,0]

    def tick(self):
        self.rot_to(self.new_rottation[0], self.rot_speed[0], 0)
        self.rot_to(self.new_rottation[1], self.rot_speed[1], 1)
        self.rot_to(self.new_rottation[2], self.rot_speed[2], 2)

    def rotate_to(self, new_angels, speed, axis='z'):
        self.new_rottation[{'x': 1, 'y': 2, 'z': 3}[axis]] = new_angels
        self.rot_speed[{'x': 1, 'y': 2, 'z': 3}[axis]] = speed

    def rotate_on(self, new_angels, speed, axis='z'):
        self.new_rottation[{'x': 1, 'y': 2, 'z': 3}[axis]] += new_angels
        self.new_rottation[{'x': 1, 'y': 2, 'z': 3}[axis]] %= 360
        self.rot_speed[{'x': 1, 'y': 2, 'z': 3}[axis]] = speed




class Camera:
    def __init__(self, game, size, scale):
        self.iscamera = True
        self.size = size
        self.scale = scale
        self.pos = (0, 0, 0)
        self.angles = (0, 0, 0)
        self.local_angles = (0, 0, 0)
        self.game = game
        self.math = game.Math
        self.parent = 'map'

    def move(self, delta):
        x, y, z = delta
        x, y = self.math.cosd(self.angles[2]) * x + self.math.sind(self.angles[2]) * y, \
               -self.math.sind(self.angles[2]) * x + self.math.cosd(self.angles[2]) * y
        self.pos = self.math.m_sum(self.pos, (x, y, z))

    def rotate(self, angles):
        a, b, c = self.math.m_sum(self.local_angles, angles)
        a1, b1, c1 = a, b, c
        # a %= 360
        # b %= 360
        # c %= 360
        if a != a1 or b != b1 or c != c1:
            print((a, b, c), (a1, b1, c1))
        self.local_angles = [a, b, c]
        self.angles = self.math.local_angles_to_global((a, b, c))


    def set_pos(self, pos):
        self.pos = pos

    def set_rotation(self, rot):
        self.local_angles = rot
        self.angles = self.math.local_angles_to_global(rot)

    def get_rotation(self):
        return self.local_angles

    def get_pos(self):
        return self.pos

    def set_parent(self, obj):
        self.parent = obj
        # if obj != 'map':
        #     print("error!!!\nThis code")
        #     exit()

    def calc_pre_render(self):
        pos = self.pos
        rot = self.angles
        obj = self.parent
        while obj != 'map':
            if obj.iscamera:
                print('err func calc_pre_render, file: Object.py\nCamera is child of camera')
                exit()
            rot = self.math.m_sum(rot, (obj.rotation[0], -obj.rotation[1], obj.rotation[2]))
            pos = self.math.m_sum(self.math.rotate_plots([pos], self.math.rotate_data((obj.rotation[0], -obj.rotation[1], obj.rotation[2])))[0], obj.coordinates_on_parent)
            obj = obj.parent
        plots, polygons = self.game.Phisics.get_map()[0]
        # plots, polygons = list, list
        polygons = polygons.copy()
        plots = plots.copy()
        for object in self.game.Phisics.get_map()[1:]:
            if not object.iscamera:
                for struct in object.get_render_data():
                    obj_plots, obj_polygons = struct
                    delta = len(plots)
                    plots.extend(obj_plots)
                    polygons.extend([self.math.m_sum(i, [delta, delta, delta]) for i in obj_polygons])
        rot_data = self.math.rotate_data(rot)
        plots = self.math.rotate_plots(plots, rot_data, pos, True)
        # ban = [i for i in plots if i[0] <= 0]
        pixels = [(int(plot[1] / plot[0] * self.scale + self.size[0] / 2),
                   int(plot[2] / plot[0] * self.scale + self.size[0] / 2)) if (plot[0] > 1e-5) else (False) for plot in
                  plots]
        return (pixels, polygons)

    def render(self, pre_render):
        self.game.screen.fill([0, 0, 0])
        pixels = pre_render[0]
        for polygon in pre_render[1]:
            if all([pixels[i] for i in polygon]):
                self.game.pygame.draw.polygon(self.game.screen, (255, 255, 255), [pixels[i] for i in polygon], 1)


if __name__ == '__main__':
    sqr1 = DynamicObject('sqr1',
                         [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]])
    sqr1.move((5, 0, 0))
    sqr1.rotate((0, 90, 0))
    sqr2 = DynamicObject('sqr2',
                         [[(0, -0.5, -0.5), (0, -0.5, 0.5), (0, 0.5, 0.5), (0, 0.5, -0.5)], [(0, 1, 2), (0, 3, 2)]])
    sqr1.add_child(sqr2)
    sqr2.move((-1, 0, 0))
    a = sqr1.get_render_data()
    exit()


class Delay:
    def __init__(self):
        self.time = 0
        pass

    def set(self, time):
        self.time = time

    def tick(self):
        if self.time > 0:
            self.time -= 1

    def get_flag(self):
        return self.time == 0